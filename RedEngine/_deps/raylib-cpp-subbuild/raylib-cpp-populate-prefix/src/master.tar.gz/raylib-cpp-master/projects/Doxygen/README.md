# raylib-cpp Doxygen

To build the documentation for raylib-cpp, run the following from root...

```
doxygen projects/Doxygen/Doxyfile
```
