# raylib-cpp VSCode Example Project

Steps to get this up and running:
    1. Make sure Raylib is installed
    2. Download the "include" folder of raylib-cpp and place it in the VSCode project folder
        (https://github.com/RobLoach/raylib-cpp/tree/master/include)
    3. Open FirstPerson.cpp, open the debug tab and press on "open a folder", select the project folder.

VSCode should restart at the welcome page, open FirstPerson.cpp again and open the Debug tab.
You should see 2 options now, "Run" and "Debug", use whatever you need, running through any of the 2 options should build a ".exe".
